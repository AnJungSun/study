import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { UsersService } from '../users/users.service';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(
    private usersService: UsersService,
    private configService: ConfigService,
  ) {
    super({
      // JWT 토큰을 요청 헤더에서 추출하는 방법 설정
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      // 토큰 만료 시간을 무시할지 여부 (false로 설정하면 만료된 토큰은 거부됨)
      ignoreExpiration: false,
      // JWT 서명을 검증할 때 사용할 비밀키
      secretOrKey: configService.get<string>('JWT_SECRET', 'your_secret_key'),
    });
  }

  /**
   * JWT 토큰이 유효한 경우 호출되는 메서드
   * 토큰에서 추출한 payload를 기반으로 사용자 정보를 조회하고 반환
   * @param payload - JWT 토큰에서 추출된 payload
   * @returns 사용자 정보
   */
  async validate(payload: any) {
    // payload에서 사용자 ID를 추출하여 데이터베이스에서 사용자 정보 조회
    const user = await this.usersService.findOne(payload.username);
    if (!user) {
      // 사용자가 존재하지 않으면 에러 발생
      throw new Error('User not found');
    }
    // 사용자 정보 반환 (이 정보는 req.user에 저장됨)
    return user;
  }
}
