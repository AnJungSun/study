import { Injectable, Logger } from '@nestjs/common';
import { CronJob } from 'cron';
import { SchedulerRegistry } from '@nestjs/schedule';

@Injectable()
export class SchedulerService {
  private readonly logger = new Logger(SchedulerService.name);

  constructor(private schedulerRegistry: SchedulerRegistry) {}

  addCronJob(name: string, cronExpression: string, callback: () => void) {
    const job = new CronJob(cronExpression, callback);
    this.schedulerRegistry.addCronJob(name, job);
    job.start();
    this.logger.log(`Job ${name} added with expression ${cronExpression}`);
  }

  deleteCron(name: string) {
    this.schedulerRegistry.deleteCronJob(name);
    this.logger.log(`Job ${name} deleted`);
  }

  getCrons() {
    return this.schedulerRegistry.getCronJobs();
  }
}

/*
Cron데코레이터 인자 문자열의 샘플

인자	의미
* * * * * *	매초 마다
45 * * * * *	매분 45초가 될때 마다 (1분45초, 2분45초 ...)
0 10 * * * *	매 시간 10분 00초가 될때 마다 (1시10분, 2시10분 ...)
0 /30 9-17 * *	오전5시~오후9시까지 매30분 간격으로(5시30분, 6시, 6시30분 ...)
0 30 11 * * 1-5	월요일~금요일 오전11시30분 마다
*/
