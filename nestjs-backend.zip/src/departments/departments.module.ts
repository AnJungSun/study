import { Module } from '@nestjs/common';

@Module({
  imports: [],
  providers: [],
})
export class DepartmentsModule {}
