import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { LoginHistoryService } from './login-history.service';
import { AuthGuard } from '@nestjs/passport';
import {
  ApiBearerAuth,
  ApiTags,
  ApiOperation,
  ApiParam,
} from '@nestjs/swagger';

@ApiTags('Login History')
@Controller('login-history')
@UseGuards(AuthGuard('jwt'))
@ApiBearerAuth()
export class LoginHistoryController {
  constructor(private loginHistoryService: LoginHistoryService) {}

  @Get(':userId')
  @ApiOperation({ summary: 'Get login history by user ID' })
  @ApiParam({ name: 'userId', type: Number })
  async findByUserId(@Param('userId') userId: number) {
    return this.loginHistoryService.findByUserId(userId);
  }

  @Get()
  @ApiOperation({ summary: 'Get all login history' })
  async findAll() {
    return this.loginHistoryService.findAll();
  }
}
