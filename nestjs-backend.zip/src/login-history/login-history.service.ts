import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { LoginHistory } from './login-history.entity';
import { User } from '../users/user.entity';

@Injectable()
export class LoginHistoryService {
  constructor(
    @InjectRepository(LoginHistory)
    private loginHistoryRepository: Repository<LoginHistory>,
  ) {}

  /**
   * 로그인 이력을 생성합니다.
   * @param userId - 로그인한 사용자의 ID
   * @returns 생성된 로그인 이력
   */
  async create(userId: number): Promise<LoginHistory> {
    const loginHistory = this.loginHistoryRepository.create({
      userId,
      loginAt: new Date(),
    });
    return this.loginHistoryRepository.save(loginHistory);
  }

  /**
   * 특정 사용자의 로그인 이력을 조회합니다.
   * @param userId - 사용자 ID
   * @returns 해당 사용자의 로그인 이력 목록
   */
  async findByUserId(userId: number): Promise<LoginHistory[]> {
    return this.loginHistoryRepository.find({
      where: { userId },
      order: { loginAt: 'DESC' }, // 최신 순으로 정렬
    });
  }

  /**
   * 모든 로그인 이력을 조회합니다.
   * @returns 모든 로그인 이력 목록
   */
  async findAll(): Promise<LoginHistory[]> {
    return this.loginHistoryRepository.find({
      order: { loginAt: 'DESC' }, // 최신 순으로 정렬
    });
  }
}
