import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LoginHistoryService } from './login-history.service';
import { LoginHistory } from './login-history.entity';

@Module({
  imports: [TypeOrmModule.forFeature([LoginHistory])],
  providers: [LoginHistoryService],
  exports: [LoginHistoryService],
})
export class LoginHistoryModule {}
